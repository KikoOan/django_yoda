from django import forms
from django.forms import ModelForm
from .models import Febes
from .models import Session
from .models import FebeParameters
from .models import Sources
from .models import Setup
from .models import Integrations



class SessionForm (ModelForm):

    class Meta:
        model = Session
        fields = ['session_name','description']


class AdminFebesForm (ModelForm):

    class Meta:
        model = Febes
        fields = "__all__"


class FebeShortForm (ModelForm):

    class Meta:
        model = FebeParameters
        fields = ['febe_name']

class FebeForm (ModelForm):

    class Meta:
        model = FebeParameters
        fields = "__all__"
    

    def __init__(self, session_id, febe_id, *args, **kwargs):
        super(FebeForm, self).__init__(*args, **kwargs)
        self.fields['session'].initial = session_id
        self.fields['session'].widget = forms.HiddenInput()
        self.fields['febe_name'].initial = febe_id
        self.fields['febe_name'].widget = forms.HiddenInput()

class SourceShortForm (ModelForm):

    class Meta:
        model = Sources
        fields = ['source_name','description']

class SourcesForm (ModelForm):

    class Meta:
        model = Sources
        fields = "__all__"

    def __init__(self, session_id, *args, **kwargs):
        super(SourcesForm, self).__init__(*args, **kwargs)
        self.fields['session'].initial = session_id
        self.fields['session'].widget = forms.HiddenInput()





class SetupShortForm (ModelForm):

    class Meta:
        model = Setup
        fields = ['setup_name']

class SetupForm (ModelForm):

    class Meta:
        model = Setup
        fields = "__all__"
    def __init__(self, session_id, *args, **kwargs):
        super(SetupForm, self).__init__(*args, **kwargs)
        self.fields['session'].initial = session_id
        self.fields['session'].widget = forms.HiddenInput()




class IntegrationsShortForm (ModelForm):

    class Meta:
        model = Integrations
        fields = ['integration_name']

class IntegrationsForm (ModelForm):

    class Meta:
        model = Integrations
        fields = "__all__"
    def __init__(self, session_id, *args, **kwargs):
        super(IntegrationsForm, self).__init__(*args, **kwargs)
        self.fields['session'].initial = session_id
        self.fields['session'].widget = forms.HiddenInput()




        
        
        